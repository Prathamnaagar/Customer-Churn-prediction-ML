"""
notebook/eda.py
===============
Complete Exploratory Data Analysis for the Customer Churn dataset.
Run as a script; all plots are saved to /assets/.
"""

import os
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import matplotlib.patches as mpatches
import seaborn as sns
import warnings
warnings.filterwarnings('ignore')

# ── paths ─────────────────────────────────────────────────────
DATA_PATH  = os.path.join('data', 'telecom_churn.csv')
ASSETS_DIR = 'assets'
os.makedirs(ASSETS_DIR, exist_ok=True)

# ── dark-mode style ───────────────────────────────────────────
PALETTE = {
    'dark':       '#1A1A2E',
    'mid':        '#16213E',
    'light':      '#E8E8E8',
    'primary':    '#6C63FF',
    'secondary':  '#FF6584',
    'accent':     '#43C6AC',
    'warn':       '#F7971E',
    'yes_color':  '#FF6584',
    'no_color':   '#6C63FF',
}

def set_style():
    plt.rcParams.update({
        'figure.facecolor': PALETTE['dark'],
        'axes.facecolor':   PALETTE['mid'],
        'axes.edgecolor':   '#3A3A5C',
        'text.color':       PALETTE['light'],
        'axes.labelcolor':  PALETTE['light'],
        'xtick.color':      PALETTE['light'],
        'ytick.color':      PALETTE['light'],
        'grid.color':       '#2A2A4A',
        'grid.alpha':       0.4,
        'axes.grid':        True,
        'font.family':      'DejaVu Sans',
        'legend.framealpha': 0.25,
        'legend.facecolor':  PALETTE['mid'],
        'legend.edgecolor':  '#3A3A5C',
    })

set_style()


# ─────────────────────────────────────────────────────────────
# LOAD & QUICK CLEAN
# ─────────────────────────────────────────────────────────────
def load_raw(path):
    df = pd.read_csv(path)
    df['TotalCharges'] = pd.to_numeric(df['TotalCharges'], errors='coerce')
    return df


# ─────────────────────────────────────────────────────────────
# HELPER: save figure
# ─────────────────────────────────────────────────────────────
def save_fig(name):
    path = os.path.join(ASSETS_DIR, name)
    plt.tight_layout()
    plt.savefig(path, dpi=150, bbox_inches='tight', facecolor=PALETTE['dark'])
    plt.close()
    print(f"  💾 {path}")


# ─────────────────────────────────────────────────────────────
# 1. DATASET OVERVIEW
# ─────────────────────────────────────────────────────────────
def dataset_overview(df):
    print("\n" + "═"*60)
    print("  1. DATASET OVERVIEW")
    print("═"*60)
    print(f"Shape          : {df.shape[0]:,} rows  ×  {df.shape[1]} columns")
    print(f"Memory usage   : {df.memory_usage(deep=True).sum() / 1024:.1f} KB")
    print(f"\nColumn dtypes:\n{df.dtypes.to_string()}")
    print(f"\nFirst 5 rows:\n{df.head().to_string()}")
    print(f"\nBasic statistics:\n{df.describe().round(2).to_string()}")


# ─────────────────────────────────────────────────────────────
# 2. MISSING VALUES
# ─────────────────────────────────────────────────────────────
def plot_missing_values(df):
    print("\n" + "═"*60)
    print("  2. MISSING VALUES")
    print("═"*60)
    missing = df.isnull().sum()
    missing_pct = (missing / len(df) * 100).round(2)
    mv = pd.DataFrame({'Count': missing, 'Pct (%)': missing_pct})
    mv = mv[mv['Count'] > 0]
    if mv.empty:
        print("  ✅ No missing values (except TotalCharges for new customers).")
    else:
        print(mv.to_string())

    fig, ax = plt.subplots(figsize=(10, 4), facecolor=PALETTE['dark'])
    ax.set_facecolor(PALETTE['mid'])
    missing_all = df.isnull().sum().sort_values(ascending=False)
    bars = ax.bar(missing_all.index, missing_all.values,
                  color=[PALETTE['secondary'] if v > 0 else PALETTE['accent']
                         for v in missing_all.values],
                  edgecolor='white', linewidth=0.3)
    ax.set_title('Missing Values per Column', fontsize=14, fontweight='bold',
                 color=PALETTE['light'])
    ax.set_ylabel('Count', fontsize=11)
    plt.xticks(rotation=45, ha='right', fontsize=8)
    save_fig('eda_01_missing_values.png')
    print("  Business Insight: TotalCharges NaN occurs for brand-new customers "
          "(tenure=0), not random missingness. Safe to fill with 0.")


# ─────────────────────────────────────────────────────────────
# 3. CLASS DISTRIBUTION
# ─────────────────────────────────────────────────────────────
def plot_churn_distribution(df):
    print("\n" + "═"*60)
    print("  3. CHURN DISTRIBUTION")
    print("═"*60)
    counts = df['Churn'].value_counts()
    pcts   = df['Churn'].value_counts(normalize=True) * 100
    print(f"  No Churn : {counts['No']:,}  ({pcts['No']:.1f}%)")
    print(f"  Churn    : {counts['Yes']:,}  ({pcts['Yes']:.1f}%)")

    fig, axes = plt.subplots(1, 2, figsize=(12, 5), facecolor=PALETTE['dark'])
    colors = [PALETTE['no_color'], PALETTE['yes_color']]

    # Count plot
    ax = axes[0]
    ax.set_facecolor(PALETTE['mid'])
    bars = ax.bar(['No Churn', 'Churn'], counts.values, color=colors,
                  edgecolor='white', linewidth=0.5, width=0.5)
    for bar, val in zip(bars, counts.values):
        ax.text(bar.get_x() + bar.get_width()/2, bar.get_height() + 40,
                f'{val:,}', ha='center', va='bottom', fontsize=12,
                color=PALETTE['light'], fontweight='bold')
    ax.set_title('Customer Count by Churn', fontsize=13, fontweight='bold',
                 color=PALETTE['light'])
    ax.set_ylabel('Count', fontsize=11)

    # Pie chart
    ax = axes[1]
    ax.set_facecolor(PALETTE['dark'])
    wedges, texts, autotexts = ax.pie(
        counts.values, labels=['No Churn', 'Churn'],
        colors=colors, autopct='%1.1f%%',
        startangle=90, wedgeprops={'edgecolor': PALETTE['dark'], 'linewidth': 2}
    )
    for autotext in autotexts:
        autotext.set_color('white')
        autotext.set_fontsize(12)
    ax.set_title('Churn Proportion', fontsize=13, fontweight='bold',
                 color=PALETTE['light'])

    save_fig('eda_02_churn_distribution.png')
    print("  Business Insight: ~23% churn rate – an imbalanced dataset. "
          "Models should be evaluated with F1/ROC-AUC, not just accuracy.")


# ─────────────────────────────────────────────────────────────
# 4. CHURN BY GENDER
# ─────────────────────────────────────────────────────────────
def plot_churn_by_gender(df):
    print("\n" + "═"*60)
    print("  4. CHURN BY GENDER")
    print("═"*60)

    fig, axes = plt.subplots(1, 2, figsize=(12, 5), facecolor=PALETTE['dark'])

    # Count plot
    ax = axes[0]
    ax.set_facecolor(PALETTE['mid'])
    gender_churn = df.groupby(['gender', 'Churn']).size().unstack(fill_value=0)
    gender_churn.plot(kind='bar', ax=ax, color=[PALETTE['no_color'], PALETTE['yes_color']],
                      edgecolor='white', linewidth=0.4, rot=0)
    ax.set_title('Churn Count by Gender', fontsize=13, fontweight='bold',
                 color=PALETTE['light'])
    ax.set_xlabel('Gender', fontsize=11)
    ax.set_ylabel('Count', fontsize=11)
    ax.legend(['No Churn', 'Churn'], framealpha=0.3)

    # Churn rate
    ax = axes[1]
    ax.set_facecolor(PALETTE['mid'])
    churn_rate = df.groupby('gender')['Churn'].apply(
        lambda x: (x == 'Yes').mean() * 100
    )
    bars = ax.bar(churn_rate.index, churn_rate.values,
                  color=[PALETTE['primary'], PALETTE['accent']],
                  edgecolor='white', linewidth=0.4, width=0.4)
    for bar, val in zip(bars, churn_rate.values):
        ax.text(bar.get_x() + bar.get_width()/2, bar.get_height() + 0.3,
                f'{val:.1f}%', ha='center', va='bottom', fontsize=12,
                color=PALETTE['light'], fontweight='bold')
    ax.set_title('Churn Rate by Gender', fontsize=13, fontweight='bold',
                 color=PALETTE['light'])
    ax.set_ylabel('Churn Rate (%)', fontsize=11)
    ax.set_ylim(0, 35)

    save_fig('eda_03_churn_by_gender.png')
    print("  Business Insight: Gender has minimal impact on churn. "
          "Focus retention efforts on other factors like contract type.")


# ─────────────────────────────────────────────────────────────
# 5. CHURN BY CONTRACT TYPE
# ─────────────────────────────────────────────────────────────
def plot_churn_by_contract(df):
    print("\n" + "═"*60)
    print("  5. CHURN BY CONTRACT TYPE")
    print("═"*60)

    fig, axes = plt.subplots(1, 2, figsize=(14, 5), facecolor=PALETTE['dark'])

    ax = axes[0]
    ax.set_facecolor(PALETTE['mid'])
    ct = df.groupby(['Contract', 'Churn']).size().unstack(fill_value=0)
    ct.plot(kind='bar', ax=ax, color=[PALETTE['no_color'], PALETTE['yes_color']],
            edgecolor='white', linewidth=0.4, rot=15)
    ax.set_title('Churn Count by Contract', fontsize=13, fontweight='bold',
                 color=PALETTE['light'])
    ax.set_xlabel('Contract Type', fontsize=11)
    ax.set_ylabel('Count', fontsize=11)
    ax.legend(['No Churn', 'Churn'], framealpha=0.3)

    ax = axes[1]
    ax.set_facecolor(PALETTE['mid'])
    rate = df.groupby('Contract')['Churn'].apply(
        lambda x: (x == 'Yes').mean() * 100
    ).sort_values(ascending=False)
    colors_bar = [PALETTE['secondary'], PALETTE['warn'], PALETTE['accent']]
    bars = ax.bar(rate.index, rate.values, color=colors_bar[:len(rate)],
                  edgecolor='white', linewidth=0.4, width=0.5)
    for bar, val in zip(bars, rate.values):
        ax.text(bar.get_x() + bar.get_width()/2, bar.get_height() + 0.5,
                f'{val:.1f}%', ha='center', va='bottom', fontsize=12,
                color=PALETTE['light'], fontweight='bold')
    ax.set_title('Churn Rate by Contract Type', fontsize=13, fontweight='bold',
                 color=PALETTE['light'])
    ax.set_ylabel('Churn Rate (%)', fontsize=11)
    plt.xticks(rotation=15)

    save_fig('eda_04_churn_by_contract.png')
    print("  Business Insight: Month-to-month customers churn ~3–4× more than "
          "annual or two-year contract holders. Converting customers to long-term "
          "contracts is the single biggest lever to reduce churn.")


# ─────────────────────────────────────────────────────────────
# 6. CHURN BY PAYMENT METHOD
# ─────────────────────────────────────────────────────────────
def plot_churn_by_payment(df):
    print("\n" + "═"*60)
    print("  6. CHURN BY PAYMENT METHOD")
    print("═"*60)

    fig, axes = plt.subplots(1, 2, figsize=(14, 5), facecolor=PALETTE['dark'])

    ax = axes[0]
    ax.set_facecolor(PALETTE['mid'])
    pm = df.groupby(['PaymentMethod', 'Churn']).size().unstack(fill_value=0)
    pm.plot(kind='bar', ax=ax, color=[PALETTE['no_color'], PALETTE['yes_color']],
            edgecolor='white', linewidth=0.4, rot=20)
    ax.set_title('Churn Count by Payment Method', fontsize=13, fontweight='bold',
                 color=PALETTE['light'])
    ax.set_xlabel('')
    ax.set_ylabel('Count', fontsize=11)
    ax.legend(['No Churn', 'Churn'], framealpha=0.3)

    ax = axes[1]
    ax.set_facecolor(PALETTE['mid'])
    rate = df.groupby('PaymentMethod')['Churn'].apply(
        lambda x: (x == 'Yes').mean() * 100
    ).sort_values(ascending=True)
    bars = ax.barh(rate.index, rate.values,
                   color=PALETTE['primary'], edgecolor='white', linewidth=0.3)
    for bar, val in zip(bars, rate.values):
        ax.text(val + 0.4, bar.get_y() + bar.get_height()/2,
                f'{val:.1f}%', va='center', fontsize=10,
                color=PALETTE['light'], fontweight='bold')
    ax.set_title('Churn Rate by Payment Method', fontsize=13, fontweight='bold',
                 color=PALETTE['light'])
    ax.set_xlabel('Churn Rate (%)', fontsize=11)

    save_fig('eda_05_churn_by_payment.png')
    print("  Business Insight: Electronic-check users churn significantly more. "
          "This may reflect less 'sticky' payment behaviour. Encouraging "
          "auto-pay methods (credit card / bank transfer) may reduce churn.")


# ─────────────────────────────────────────────────────────────
# 7. MONTHLY CHARGES VS CHURN
# ─────────────────────────────────────────────────────────────
def plot_monthly_charges_vs_churn(df):
    print("\n" + "═"*60)
    print("  7. MONTHLY CHARGES VS CHURN")
    print("═"*60)

    fig, axes = plt.subplots(1, 3, figsize=(16, 5), facecolor=PALETTE['dark'])

    # Histogram
    ax = axes[0]
    ax.set_facecolor(PALETTE['mid'])
    for label, color in [('No', PALETTE['no_color']), ('Yes', PALETTE['yes_color'])]:
        subset = df[df['Churn'] == label]['MonthlyCharges']
        ax.hist(subset, bins=30, alpha=0.65, color=color,
                edgecolor='white', linewidth=0.2,
                label=f"{'No Churn' if label=='No' else 'Churn'}")
    ax.set_title('Monthly Charges Distribution', fontsize=12, fontweight='bold',
                 color=PALETTE['light'])
    ax.set_xlabel('Monthly Charges ($)', fontsize=11)
    ax.set_ylabel('Count', fontsize=11)
    ax.legend()

    # Box plot
    ax = axes[1]
    ax.set_facecolor(PALETTE['mid'])
    data_no  = df[df['Churn'] == 'No']['MonthlyCharges']
    data_yes = df[df['Churn'] == 'Yes']['MonthlyCharges']
    bp = ax.boxplot([data_no, data_yes],
                    labels=['No Churn', 'Churn'],
                    patch_artist=True,
                    boxprops=dict(facecolor=PALETTE['mid']),
                    medianprops=dict(color=PALETTE['warn'], linewidth=2))
    bp['boxes'][0].set_facecolor(PALETTE['no_color'] + '99')
    bp['boxes'][1].set_facecolor(PALETTE['yes_color'] + '99')
    ax.set_title('Monthly Charges Boxplot', fontsize=12, fontweight='bold',
                 color=PALETTE['light'])
    ax.set_ylabel('Monthly Charges ($)', fontsize=11)

    # Violin plot
    ax = axes[2]
    ax.set_facecolor(PALETTE['mid'])
    parts = ax.violinplot([data_no, data_yes], showmedians=True, showmeans=False)
    for i, pc in enumerate(parts['bodies']):
        pc.set_facecolor([PALETTE['no_color'], PALETTE['yes_color']][i])
        pc.set_alpha(0.7)
    parts['cmedians'].set_colors(PALETTE['warn'])
    ax.set_xticks([1, 2])
    ax.set_xticklabels(['No Churn', 'Churn'])
    ax.set_title('Monthly Charges Violin Plot', fontsize=12, fontweight='bold',
                 color=PALETTE['light'])
    ax.set_ylabel('Monthly Charges ($)', fontsize=11)

    save_fig('eda_06_monthly_charges_vs_churn.png')
    print("  Business Insight: Churned customers pay notably higher monthly "
          "charges. High-cost subscribers may feel the price isn't justified. "
          "Consider targeted loyalty discounts for high-spend customers.")


# ─────────────────────────────────────────────────────────────
# 8. TENURE VS CHURN
# ─────────────────────────────────────────────────────────────
def plot_tenure_vs_churn(df):
    print("\n" + "═"*60)
    print("  8. TENURE VS CHURN")
    print("═"*60)

    fig, axes = plt.subplots(1, 2, figsize=(14, 5), facecolor=PALETTE['dark'])

    # Histogram
    ax = axes[0]
    ax.set_facecolor(PALETTE['mid'])
    for label, color in [('No', PALETTE['no_color']), ('Yes', PALETTE['yes_color'])]:
        subset = df[df['Churn'] == label]['tenure']
        ax.hist(subset, bins=25, alpha=0.65, color=color,
                edgecolor='white', linewidth=0.2,
                label=f"{'No Churn' if label=='No' else 'Churn'}")
    ax.set_title('Tenure Distribution by Churn', fontsize=13, fontweight='bold',
                 color=PALETTE['light'])
    ax.set_xlabel('Tenure (months)', fontsize=11)
    ax.set_ylabel('Count', fontsize=11)
    ax.legend()

    # Churn rate by tenure band
    ax = axes[1]
    ax.set_facecolor(PALETTE['mid'])
    df['TenureBand'] = pd.cut(df['tenure'],
                               bins=[-1, 12, 24, 36, 48, 60, np.inf],
                               labels=['0–12', '12–24', '24–36',
                                       '36–48', '48–60', '60+'])
    rate = df.groupby('TenureBand', observed=True)['Churn'].apply(
        lambda x: (x == 'Yes').mean() * 100
    )
    bars = ax.bar(rate.index.astype(str), rate.values,
                  color=PALETTE['accent'], edgecolor='white',
                  linewidth=0.4, width=0.6, alpha=0.85)
    for bar, val in zip(bars, rate.values):
        ax.text(bar.get_x() + bar.get_width()/2, bar.get_height() + 0.4,
                f'{val:.1f}%', ha='center', va='bottom', fontsize=10,
                color=PALETTE['light'], fontweight='bold')
    ax.set_title('Churn Rate by Tenure Band', fontsize=13, fontweight='bold',
                 color=PALETTE['light'])
    ax.set_xlabel('Tenure (months)', fontsize=11)
    ax.set_ylabel('Churn Rate (%)', fontsize=11)
    df.drop(columns=['TenureBand'], inplace=True)

    save_fig('eda_07_tenure_vs_churn.png')
    print("  Business Insight: Churn is highest in the first 12 months. "
          "Customers who survive past 2 years are far more loyal. "
          "Invest in early-stage onboarding and engagement programs.")


# ─────────────────────────────────────────────────────────────
# 9. CORRELATION HEATMAP
# ─────────────────────────────────────────────────────────────
def plot_correlation_heatmap(df):
    print("\n" + "═"*60)
    print("  9. CORRELATION HEATMAP")
    print("═"*60)

    df_num = df.copy()
    df_num['Churn_binary'] = (df_num['Churn'] == 'Yes').astype(int)

    num_cols = ['SeniorCitizen', 'tenure', 'MonthlyCharges',
                'TotalCharges', 'Churn_binary']
    num_cols = [c for c in num_cols if c in df_num.columns]
    corr = df_num[num_cols].corr()

    fig, ax = plt.subplots(figsize=(8, 6), facecolor=PALETTE['dark'])
    ax.set_facecolor(PALETTE['dark'])
    mask = np.zeros_like(corr, dtype=bool)
    np.fill_diagonal(mask, True)

    cmap = sns.diverging_palette(240, 10, as_cmap=True)
    sns.heatmap(
        corr, ax=ax, annot=True, fmt='.2f', cmap=cmap,
        linewidths=0.5, linecolor=PALETTE['dark'],
        annot_kws={'size': 11, 'color': 'white'},
        vmin=-1, vmax=1,
    )
    ax.set_title('Correlation Heatmap (Numerical Features)',
                 fontsize=14, fontweight='bold', color=PALETTE['light'], pad=15)
    plt.xticks(rotation=30, ha='right')
    plt.yticks(rotation=0)
    for text in ax.texts:
        text.set_color('white')

    save_fig('eda_08_correlation_heatmap.png')
    print("  Business Insight: MonthlyCharges and TotalCharges are highly "
          "correlated (expected). Tenure has a negative correlation with "
          "Churn – longer-tenured customers are less likely to leave.")


# ─────────────────────────────────────────────────────────────
# 10. INTERNET SERVICE & SENIOR CITIZEN
# ─────────────────────────────────────────────────────────────
def plot_additional_insights(df):
    print("\n" + "═"*60)
    print("  10. ADDITIONAL INSIGHTS")
    print("═"*60)

    fig, axes = plt.subplots(1, 2, figsize=(14, 5), facecolor=PALETTE['dark'])

    # Internet service
    ax = axes[0]
    ax.set_facecolor(PALETTE['mid'])
    rate = df.groupby('InternetService')['Churn'].apply(
        lambda x: (x == 'Yes').mean() * 100
    ).sort_values(ascending=False)
    bars = ax.bar(rate.index, rate.values,
                  color=[PALETTE['secondary'], PALETTE['warn'], PALETTE['accent']],
                  edgecolor='white', linewidth=0.4, width=0.5, alpha=0.85)
    for bar, val in zip(bars, rate.values):
        ax.text(bar.get_x() + bar.get_width()/2, bar.get_height() + 0.4,
                f'{val:.1f}%', ha='center', va='bottom', fontsize=12,
                color=PALETTE['light'], fontweight='bold')
    ax.set_title('Churn Rate by Internet Service', fontsize=13,
                 fontweight='bold', color=PALETTE['light'])
    ax.set_ylabel('Churn Rate (%)', fontsize=11)

    # Senior citizen
    ax = axes[1]
    ax.set_facecolor(PALETTE['mid'])
    rate_sc = df.groupby('SeniorCitizen')['Churn'].apply(
        lambda x: (x == 'Yes').mean() * 100
    )
    rate_sc.index = ['Non-Senior', 'Senior']
    bars = ax.bar(rate_sc.index, rate_sc.values,
                  color=[PALETTE['accent'], PALETTE['secondary']],
                  edgecolor='white', linewidth=0.4, width=0.4, alpha=0.85)
    for bar, val in zip(bars, rate_sc.values):
        ax.text(bar.get_x() + bar.get_width()/2, bar.get_height() + 0.4,
                f'{val:.1f}%', ha='center', va='bottom', fontsize=12,
                color=PALETTE['light'], fontweight='bold')
    ax.set_title('Churn Rate: Senior vs Non-Senior', fontsize=13,
                 fontweight='bold', color=PALETTE['light'])
    ax.set_ylabel('Churn Rate (%)', fontsize=11)

    save_fig('eda_09_internet_senior.png')
    print("  Business Insight: Fiber optic users churn most (~30%), despite "
          "paying more. Service quality or value-for-money perceptions may "
          "be the cause. Senior citizens also churn at a higher rate (~33%).")


# ─────────────────────────────────────────────────────────────
# MAIN
# ─────────────────────────────────────────────────────────────
def main():
    print("=" * 60)
    print("  CUSTOMER CHURN – EXPLORATORY DATA ANALYSIS")
    print("=" * 60)
    df = load_raw(DATA_PATH)

    dataset_overview(df)
    plot_missing_values(df)
    plot_churn_distribution(df)
    plot_churn_by_gender(df)
    plot_churn_by_contract(df)
    plot_churn_by_payment(df)
    plot_monthly_charges_vs_churn(df)
    plot_tenure_vs_churn(df)
    plot_correlation_heatmap(df)
    plot_additional_insights(df)

    print("\n" + "=" * 60)
    print("  ✅ EDA COMPLETE — all charts saved to /assets/")
    print("=" * 60)


if __name__ == '__main__':
    main()
