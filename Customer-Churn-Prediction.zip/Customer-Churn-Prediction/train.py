"""
train.py
========
Model training, hyperparameter tuning, evaluation, and saving
for the Customer Churn Prediction project.
"""

import os
import warnings
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import matplotlib.patches as mpatches
import seaborn as sns
from sklearn.linear_model import LogisticRegression
from sklearn.ensemble import RandomForestClassifier, GradientBoostingClassifier
from sklearn.model_selection import GridSearchCV, cross_val_score
from sklearn.metrics import (
    accuracy_score, precision_score, recall_score, f1_score,
    roc_auc_score, confusion_matrix, classification_report,
    roc_curve, ConfusionMatrixDisplay
)
import joblib

from preprocess import preprocess_pipeline

warnings.filterwarnings('ignore')

# ── palette ─────────────────────────────────────────────────
PALETTE = {
    'primary':   '#6C63FF',
    'secondary': '#FF6584',
    'accent':    '#43C6AC',
    'dark':      '#1A1A2E',
    'mid':       '#16213E',
    'light':     '#E8E8E8',
}

def set_style():
    plt.rcParams.update({
        'figure.facecolor': PALETTE['dark'],
        'axes.facecolor':   PALETTE['mid'],
        'axes.edgecolor':   PALETTE['light'],
        'text.color':       PALETTE['light'],
        'axes.labelcolor':  PALETTE['light'],
        'xtick.color':      PALETTE['light'],
        'ytick.color':      PALETTE['light'],
        'grid.color':       '#2A2A4A',
        'grid.alpha':       0.5,
        'axes.grid':        True,
        'font.family':      'DejaVu Sans',
    })

set_style()

ASSETS = 'assets'
os.makedirs(ASSETS, exist_ok=True)
os.makedirs('models', exist_ok=True)

# ─────────────────────────────────────────────────────────────
# 1. DEFINE MODELS & PARAM GRIDS
# ─────────────────────────────────────────────────────────────
MODELS = {
    'Logistic Regression': {
        'model': LogisticRegression(max_iter=1000, random_state=42),
        'params': {
            'C': [0.01, 0.1, 1, 10],
            'solver': ['lbfgs', 'liblinear'],
            'class_weight': [None, 'balanced'],
        }
    },
    'Random Forest': {
        'model': RandomForestClassifier(random_state=42, n_jobs=-1),
        'params': {
            'n_estimators': [100, 200],
            'max_depth': [5, 10, None],
            'min_samples_split': [2, 5],
            'class_weight': [None, 'balanced'],
        }
    },
    'Gradient Boosting': {
        'model': GradientBoostingClassifier(random_state=42),
        'params': {
            'n_estimators': [100, 200],
            'learning_rate': [0.05, 0.1, 0.2],
            'max_depth': [3, 5],
            'subsample': [0.8, 1.0],
        }
    },
}


# ─────────────────────────────────────────────────────────────
# 2. TRAIN WITH GRIDSEARCHCV
# ─────────────────────────────────────────────────────────────
def train_models(X_train, y_train):
    """Run GridSearchCV for every model; return best estimators."""
    best_estimators = {}
    for name, cfg in MODELS.items():
        print(f"\n🔍 Tuning: {name}")
        gs = GridSearchCV(
            cfg['model'], cfg['params'],
            cv=5, scoring='roc_auc', n_jobs=-1, verbose=0
        )
        gs.fit(X_train, y_train)
        best_estimators[name] = gs.best_estimator_
        print(f"   Best params : {gs.best_params_}")
        print(f"   CV ROC-AUC  : {gs.best_score_:.4f}")
    return best_estimators


# ─────────────────────────────────────────────────────────────
# 3. EVALUATE MODELS
# ─────────────────────────────────────────────────────────────
def evaluate_models(estimators: dict, X_test, y_test) -> pd.DataFrame:
    """Return a DataFrame with all evaluation metrics."""
    rows = []
    for name, model in estimators.items():
        y_pred  = model.predict(X_test)
        y_proba = model.predict_proba(X_test)[:, 1]
        rows.append({
            'Model':     name,
            'Accuracy':  accuracy_score(y_test, y_pred),
            'Precision': precision_score(y_test, y_pred),
            'Recall':    recall_score(y_test, y_pred),
            'F1 Score':  f1_score(y_test, y_pred),
            'ROC-AUC':   roc_auc_score(y_test, y_proba),
        })
        print(f"\n{'─'*50}")
        print(f"  {name}")
        print(f"{'─'*50}")
        print(classification_report(y_test, y_pred, target_names=['No Churn','Churn']))
    return pd.DataFrame(rows).set_index('Model')


# ─────────────────────────────────────────────────────────────
# 4. PLOT – CONFUSION MATRICES
# ─────────────────────────────────────────────────────────────
def plot_confusion_matrices(estimators, X_test, y_test):
    n = len(estimators)
    fig, axes = plt.subplots(1, n, figsize=(6 * n, 5),
                             facecolor=PALETTE['dark'])
    fig.suptitle('Confusion Matrices', color=PALETTE['light'],
                 fontsize=16, fontweight='bold', y=1.02)

    for ax, (name, model) in zip(axes, estimators.items()):
        cm = confusion_matrix(y_test, model.predict(X_test))
        disp = ConfusionMatrixDisplay(cm, display_labels=['No Churn', 'Churn'])
        disp.plot(ax=ax, colorbar=False, cmap='Blues')
        ax.set_title(name, color=PALETTE['light'], fontsize=12, pad=10)
        ax.set_facecolor(PALETTE['mid'])
        for text in ax.texts:
            text.set_color('white')

    plt.tight_layout()
    path = os.path.join(ASSETS, 'confusion_matrices.png')
    plt.savefig(path, dpi=150, bbox_inches='tight', facecolor=PALETTE['dark'])
    plt.close()
    print(f"💾 Saved: {path}")


# ─────────────────────────────────────────────────────────────
# 5. PLOT – ROC CURVES
# ─────────────────────────────────────────────────────────────
def plot_roc_curves(estimators, X_test, y_test):
    colors = [PALETTE['primary'], PALETTE['secondary'], PALETTE['accent']]
    fig, ax = plt.subplots(figsize=(8, 6), facecolor=PALETTE['dark'])
    ax.set_facecolor(PALETTE['mid'])

    for (name, model), color in zip(estimators.items(), colors):
        y_proba = model.predict_proba(X_test)[:, 1]
        fpr, tpr, _ = roc_curve(y_test, y_proba)
        auc = roc_auc_score(y_test, y_proba)
        ax.plot(fpr, tpr, color=color, lw=2.5,
                label=f'{name}  (AUC = {auc:.3f})')

    ax.plot([0, 1], [0, 1], 'w--', lw=1.5, alpha=0.5, label='Random Classifier')
    ax.set_xlabel('False Positive Rate', fontsize=12)
    ax.set_ylabel('True Positive Rate', fontsize=12)
    ax.set_title('ROC Curves – Model Comparison', fontsize=15,
                 fontweight='bold', color=PALETTE['light'])
    ax.legend(loc='lower right', framealpha=0.3)

    path = os.path.join(ASSETS, 'roc_curves.png')
    plt.tight_layout()
    plt.savefig(path, dpi=150, bbox_inches='tight', facecolor=PALETTE['dark'])
    plt.close()
    print(f"💾 Saved: {path}")


# ─────────────────────────────────────────────────────────────
# 6. PLOT – MODEL COMPARISON BAR CHART
# ─────────────────────────────────────────────────────────────
def plot_model_comparison(results: pd.DataFrame):
    fig, ax = plt.subplots(figsize=(11, 6), facecolor=PALETTE['dark'])
    ax.set_facecolor(PALETTE['mid'])

    x     = np.arange(len(results))
    width = 0.16
    metrics = results.columns.tolist()
    bar_colors = [PALETTE['primary'], PALETTE['secondary'],
                  PALETTE['accent'], '#F7971E', '#56CCF2']

    for i, (metric, color) in enumerate(zip(metrics, bar_colors)):
        bars = ax.bar(x + i * width, results[metric], width,
                      label=metric, color=color, alpha=0.88, edgecolor='white', linewidth=0.4)

    ax.set_xticks(x + width * 2)
    ax.set_xticklabels(results.index, fontsize=12)
    ax.set_ylim(0, 1.05)
    ax.set_ylabel('Score', fontsize=12)
    ax.set_title('Model Performance Comparison', fontsize=15,
                 fontweight='bold', color=PALETTE['light'])
    ax.legend(loc='lower right', framealpha=0.3)

    path = os.path.join(ASSETS, 'model_comparison.png')
    plt.tight_layout()
    plt.savefig(path, dpi=150, bbox_inches='tight', facecolor=PALETTE['dark'])
    plt.close()
    print(f"💾 Saved: {path}")


# ─────────────────────────────────────────────────────────────
# 7. FEATURE IMPORTANCE
# ─────────────────────────────────────────────────────────────
def plot_feature_importance(estimators, feature_names, top_n=20):
    tree_models = {
        k: v for k, v in estimators.items()
        if hasattr(v, 'feature_importances_')
    }

    for name, model in tree_models.items():
        importances = model.feature_importances_
        indices = np.argsort(importances)[::-1][:top_n]
        top_features = [feature_names[i] for i in indices]
        top_imp      = importances[indices]

        fig, ax = plt.subplots(figsize=(10, 8), facecolor=PALETTE['dark'])
        ax.set_facecolor(PALETTE['mid'])

        bars = ax.barh(range(top_n), top_imp[::-1],
                       color=PALETTE['primary'], alpha=0.85, edgecolor='white', linewidth=0.3)
        ax.set_yticks(range(top_n))
        ax.set_yticklabels(top_features[::-1], fontsize=9)
        ax.set_xlabel('Importance Score', fontsize=12)
        ax.set_title(f'Top {top_n} Feature Importances – {name}',
                     fontsize=14, fontweight='bold', color=PALETTE['light'])

        safe_name = name.lower().replace(' ', '_')
        path = os.path.join(ASSETS, f'feature_importance_{safe_name}.png')
        plt.tight_layout()
        plt.savefig(path, dpi=150, bbox_inches='tight', facecolor=PALETTE['dark'])
        plt.close()
        print(f"💾 Saved: {path}")


# ─────────────────────────────────────────────────────────────
# 8. SAVE BEST MODEL
# ─────────────────────────────────────────────────────────────
def save_best_model(estimators, results, model_dir='models'):
    best_name = results['ROC-AUC'].idxmax()
    best_model = estimators[best_name]
    path = os.path.join(model_dir, 'best_model.pkl')
    joblib.dump(best_model, path)
    joblib.dump(best_name, os.path.join(model_dir, 'best_model_name.pkl'))
    print(f"\n🏆 Best model: {best_name}  (ROC-AUC = {results.loc[best_name,'ROC-AUC']:.4f})")
    print(f"💾 Saved to  : {path}")
    return best_name, best_model


# ─────────────────────────────────────────────────────────────
# MAIN
# ─────────────────────────────────────────────────────────────
def main():
    print("=" * 60)
    print("  CUSTOMER CHURN PREDICTION – MODEL TRAINING PIPELINE")
    print("=" * 60)

    # Preprocessing
    X_train, X_test, y_train, y_test, feature_names = preprocess_pipeline(
        os.path.join('data', 'telecom_churn.csv')
    )

    # Training
    print("\n" + "=" * 60)
    print("  HYPERPARAMETER TUNING WITH GridSearchCV")
    print("=" * 60)
    estimators = train_models(X_train, y_train)

    # Evaluation
    print("\n" + "=" * 60)
    print("  EVALUATION METRICS")
    print("=" * 60)
    results = evaluate_models(estimators, X_test, y_test)

    print("\n📊 Summary Table:")
    print(results.round(4).to_string())

    # Plots
    print("\n📈 Generating visualisations…")
    plot_confusion_matrices(estimators, X_test, y_test)
    plot_roc_curves(estimators, X_test, y_test)
    plot_model_comparison(results)
    plot_feature_importance(estimators, feature_names)

    # Save
    best_name, best_model = save_best_model(estimators, results)

    # Save results table
    results.round(4).to_csv(os.path.join(ASSETS, 'model_results.csv'))

    print("\n✅ Training pipeline complete!")
    return estimators, results


if __name__ == '__main__':
    main()
