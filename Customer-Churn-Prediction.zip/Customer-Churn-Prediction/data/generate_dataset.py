"""
Generate a realistic synthetic Telecom Customer Churn dataset.
Based on the structure of the well-known IBM Telco Customer Churn dataset.
"""

import numpy as np
import pandas as pd

np.random.seed(42)
N = 7043

def generate_churn_dataset():
    gender = np.random.choice(['Male', 'Female'], N)
    senior_citizen = np.random.choice([0, 1], N, p=[0.84, 0.16])
    partner = np.random.choice(['Yes', 'No'], N, p=[0.48, 0.52])
    dependents = np.random.choice(['Yes', 'No'], N, p=[0.30, 0.70])

    tenure = np.random.randint(0, 73, N)

    phone_service = np.random.choice(['Yes', 'No'], N, p=[0.90, 0.10])
    multiple_lines = np.where(
        phone_service == 'No', 'No phone service',
        np.random.choice(['Yes', 'No'], N, p=[0.42, 0.58])
    )

    internet_service = np.random.choice(['DSL', 'Fiber optic', 'No'], N, p=[0.34, 0.44, 0.22])

    def internet_addon(no_label):
        return np.where(
            internet_service == 'No', no_label,
            np.random.choice(['Yes', 'No'], N, p=[0.5, 0.5])
        )

    online_security  = internet_addon('No internet service')
    online_backup    = internet_addon('No internet service')
    device_protection= internet_addon('No internet service')
    tech_support     = internet_addon('No internet service')
    streaming_tv     = internet_addon('No internet service')
    streaming_movies = internet_addon('No internet service')

    contract = np.random.choice(['Month-to-month', 'One year', 'Two year'], N, p=[0.55, 0.21, 0.24])
    paperless_billing = np.random.choice(['Yes', 'No'], N, p=[0.59, 0.41])
    payment_method = np.random.choice(
        ['Electronic check', 'Mailed check', 'Bank transfer (automatic)', 'Credit card (automatic)'],
        N, p=[0.34, 0.23, 0.22, 0.21]
    )

    # Monthly charges correlated with services
    base_charge = 20.0
    monthly_charges = (
        base_charge
        + (phone_service == 'Yes') * 10
        + (multiple_lines == 'Yes') * 10
        + (internet_service == 'DSL') * 20
        + (internet_service == 'Fiber optic') * 35
        + (online_security == 'Yes') * 5
        + (online_backup == 'Yes') * 5
        + (device_protection == 'Yes') * 5
        + (tech_support == 'Yes') * 5
        + (streaming_tv == 'Yes') * 5
        + (streaming_movies == 'Yes') * 5
        + np.random.normal(0, 3, N)
    ).clip(18.8, 118.75)

    # Introduce ~11 NaN in TotalCharges (replicates real dataset quirk)
    total_charges = (monthly_charges * tenure).round(2).astype(float)
    nan_idx = np.random.choice(np.where(tenure == 0)[0], size=min(11, (tenure == 0).sum()), replace=False)
    total_charges[nan_idx] = np.nan

    # Churn probability model (realistic rules)
    churn_prob = (
        0.05
        + 0.25 * (contract == 'Month-to-month')
        - 0.15 * (contract == 'Two year')
        + 0.12 * (internet_service == 'Fiber optic')
        + 0.10 * (payment_method == 'Electronic check')
        - 0.10 * (tenure > 36)
        - 0.08 * (tenure > 60)
        + 0.08 * (senior_citizen == 1)
        + 0.05 * (monthly_charges > 70)
        - 0.05 * (partner == 'Yes')
        - 0.05 * (dependents == 'Yes')
        + 0.04 * (tech_support == 'No') * (internet_service != 'No')
        + 0.04 * (online_security == 'No') * (internet_service != 'No')
        + np.random.normal(0, 0.05, N)
    ).clip(0.02, 0.95)

    churn = np.where(np.random.random(N) < churn_prob, 'Yes', 'No')

    customer_id = [f'CUST-{str(i).zfill(5)}' for i in range(1, N + 1)]

    df = pd.DataFrame({
        'customerID': customer_id,
        'gender': gender,
        'SeniorCitizen': senior_citizen,
        'Partner': partner,
        'Dependents': dependents,
        'tenure': tenure,
        'PhoneService': phone_service,
        'MultipleLines': multiple_lines,
        'InternetService': internet_service,
        'OnlineSecurity': online_security,
        'OnlineBackup': online_backup,
        'DeviceProtection': device_protection,
        'TechSupport': tech_support,
        'StreamingTV': streaming_tv,
        'StreamingMovies': streaming_movies,
        'Contract': contract,
        'PaperlessBilling': paperless_billing,
        'PaymentMethod': payment_method,
        'MonthlyCharges': monthly_charges.round(2),
        'TotalCharges': total_charges,
        'Churn': churn,
    })

    return df


if __name__ == '__main__':
    df = generate_churn_dataset()
    df.to_csv('telecom_churn.csv', index=False)
    print(f"Dataset saved: {df.shape[0]} rows × {df.shape[1]} cols")
    print(f"Churn rate: {(df['Churn'] == 'Yes').mean():.1%}")
