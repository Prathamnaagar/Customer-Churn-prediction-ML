# 🔮 Customer Churn Prediction — End-to-End ML Project

<p align="center">
  <img src="assets/eda_02_churn_distribution.png" width="600" alt="Churn Distribution"/>
</p>

<p align="center">
  <img src="https://img.shields.io/badge/Python-3.10+-3776AB?logo=python&logoColor=white"/>
  <img src="https://img.shields.io/badge/scikit--learn-1.3+-F7931E?logo=scikit-learn&logoColor=white"/>
  <img src="https://img.shields.io/badge/Streamlit-1.28+-FF4B4B?logo=streamlit&logoColor=white"/>
  <img src="https://img.shields.io/badge/License-MIT-green"/>
</p>

---

## 📌 Project Overview

A production-ready, end-to-end machine learning pipeline that predicts **which telecom customers are likely to churn**, complete with:

- Rich Exploratory Data Analysis (EDA) with 9 visualisation sets
- Three classifier models with GridSearchCV hyperparameter tuning
- Full model evaluation suite (Accuracy, Precision, Recall, F1, ROC-AUC)
- A professional **Streamlit web application** with probability gauge, risk scoring, and actionable recommendations
- Batch prediction via CSV upload with downloadable results

---

## ❓ Problem Statement

Customer churn is one of the most costly problems in subscription businesses. Acquiring a new customer can cost **5–7× more** than retaining an existing one. This project builds a machine learning model that identifies at-risk customers **before** they leave, enabling targeted retention actions.

---

## 📊 Dataset Information

| Property | Value |
|---|---|
| Source | Synthetic Telecom Churn (IBM Telco structure) |
| Rows | 7,043 |
| Features | 20 (raw) → 38 (after engineering & encoding) |
| Target | `Churn` — Yes / No |
| Class balance | ~76.6% No Churn / 23.4% Churn |

**Key features:**
- **Demographics:** gender, SeniorCitizen, Partner, Dependents
- **Services:** PhoneService, InternetService, Streaming, TechSupport, etc.
- **Account:** tenure, Contract, PaperlessBilling, PaymentMethod
- **Charges:** MonthlyCharges, TotalCharges

---

## 🛠️ Technologies Used

| Category | Library / Tool |
|---|---|
| Language | Python 3.10+ |
| Data Manipulation | pandas, NumPy |
| Machine Learning | scikit-learn |
| Visualisation | matplotlib, seaborn |
| Web Application | Streamlit |
| Model Persistence | joblib |

---

## 🔄 Workflow

```
Raw Data
   ↓
data/generate_dataset.py      ← generates telecom_churn.csv
   ↓
preprocess.py                 ← clean, engineer, encode, scale, split
   ↓
train.py                      ← GridSearchCV · evaluate · save best model
   ↓
notebook/eda.py               ← exploratory analysis charts → assets/
   ↓
app.py                        ← Streamlit web app
```

### Feature Engineering
| Feature | Description |
|---|---|
| `TenureBand` | Bucketed tenure: 0–12m, 12–24m, 24–48m, 48–60m, 60m+ |
| `NumServices` | Count of subscribed add-on services |
| `ChargePerService` | MonthlyCharges ÷ NumServices |
| `LongTenure` | 1 if tenure > 24 months |
| `HighValue` | 1 if MonthlyCharges > median |

---

## 📈 Model Performance

| Model | Accuracy | Precision | Recall | F1 Score | ROC-AUC |
|---|---|---|---|---|---|
| Logistic Regression | 0.7800 | 0.5941 | 0.1824 | 0.2791 | **0.7847** |
| Random Forest | 0.7104 | 0.4179 | 0.6109 | 0.4963 | 0.7614 |
| Gradient Boosting | 0.7729 | 0.5714 | 0.1094 | 0.1837 | 0.7750 |

> **Best model:** Logistic Regression (ROC-AUC = 0.7847)

<p align="center">
  <img src="assets/roc_curves.png" width="600" alt="ROC Curves"/>
</p>

---

## 🚀 Installation & Setup

### 1. Clone the repository
```bash
git clone https://github.com/yourusername/Customer-Churn-Prediction.git
cd Customer-Churn-Prediction
```

### 2. Create a virtual environment
```bash
python -m venv venv
source venv/bin/activate      # Linux / macOS
venv\Scripts\activate         # Windows
```

### 3. Install dependencies
```bash
pip install -r requirements.txt
```

### 4. Generate the dataset
```bash
python data/generate_dataset.py
```

### 5. Run EDA
```bash
python notebook/eda.py
```

### 6. Train the models
```bash
python train.py
```

### 7. Launch the Streamlit app
```bash
streamlit run app.py
```

Open **http://localhost:8501** in your browser.

---

## 📁 Project Structure

```
Customer-Churn-Prediction/
│
├── data/
│   ├── generate_dataset.py     # Synthetic dataset generator
│   └── telecom_churn.csv       # Generated dataset (7,043 rows)
│
├── notebook/
│   └── eda.py                  # Full EDA script
│
├── models/
│   ├── best_model.pkl          # Saved best classifier
│   ├── scaler.pkl              # Fitted StandardScaler
│   ├── feature_names.pkl       # Training feature list
│   └── num_cols.pkl            # Numerical columns list
│
├── assets/                     # All generated charts
│
├── app.py                      # Streamlit web application
├── preprocess.py               # Preprocessing pipeline
├── train.py                    # Model training & evaluation
├── requirements.txt
└── README.md
```

---

## 🖥️ Streamlit App Features

| Feature | Details |
|---|---|
| 🌙 Dark Mode | Full dark-theme UI |
| 🔮 Gauge Chart | Semi-circular churn probability gauge |
| 📊 Progress Bar | Visual confidence display |
| 💡 Recommendations | Actionable retention suggestions per prediction |
| 📁 Batch Upload | CSV batch prediction with download |
| 📈 EDA Dashboard | All EDA charts inside the app |
| 📉 Model Dashboard | Performance table + all evaluation charts |
| ✅ Input Validation | Sidebar conditional inputs |

---

## 🔑 Key Business Insights

1. **Contract type is the strongest churn predictor** — Month-to-month customers churn 3–4× more
2. **First-year customers are most at risk** — 0–12 month cohort has the highest churn rate
3. **High monthly charges correlate with churn** — Price sensitivity is real; loyalty discounts help
4. **Electronic check users churn more** — Auto-pay enrollment reduces churn risk
5. **Fiber optic customers churn most** — Proactive service quality outreach is needed

---

## 🔮 Future Improvements

- [ ] Add XGBoost / LightGBM when available in environment
- [ ] SHAP value explanations for individual predictions
- [ ] Real-time model retraining pipeline
- [ ] A/B test framework for retention interventions
- [ ] Customer lifetime value (CLV) integration
- [ ] REST API with FastAPI for model serving
- [ ] Docker containerisation
- [ ] CI/CD pipeline with GitHub Actions

---

## 📄 License

This project is licensed under the MIT License — see [LICENSE](LICENSE) for details.

---

<p align="center">
  Built with ❤️ for Data Science portfolios
</p>
