"""
preprocess.py
=============
Data cleaning, feature engineering, and preprocessing pipeline
for the Customer Churn Prediction project.
"""

import numpy as np
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler, LabelEncoder
import joblib
import os

# ─────────────────────────────────────────────────────────────
# 1. LOAD DATA
# ─────────────────────────────────────────────────────────────
def load_data(filepath: str) -> pd.DataFrame:
    """Load raw CSV into a DataFrame."""
    df = pd.read_csv(filepath)
    print(f"✅ Loaded: {df.shape[0]:,} rows × {df.shape[1]} columns")
    return df


# ─────────────────────────────────────────────────────────────
# 2. CLEAN DATA
# ─────────────────────────────────────────────────────────────
def clean_data(df: pd.DataFrame) -> pd.DataFrame:
    """
    Handle missing values, duplicates, and data-type issues.
    Returns cleaned DataFrame.
    """
    df = df.copy()

    # Drop customerID – not a predictive feature
    if 'customerID' in df.columns:
        df.drop(columns=['customerID'], inplace=True)

    # TotalCharges arrives as object because of blank strings in some raw sources
    if df['TotalCharges'].dtype == object:
        df['TotalCharges'] = pd.to_numeric(df['TotalCharges'], errors='coerce')

    # Fill NaN TotalCharges with 0 (new customers with tenure == 0)
    missing_tc = df['TotalCharges'].isna().sum()
    df['TotalCharges'].fillna(0, inplace=True)
    print(f"  • TotalCharges NaNs filled: {missing_tc}")

    # Remove duplicate rows
    dups = df.duplicated().sum()
    df.drop_duplicates(inplace=True)
    print(f"  • Duplicate rows removed: {dups}")

    # Encode target: Yes → 1, No → 0
    df['Churn'] = (df['Churn'] == 'Yes').astype(int)

    print(f"✅ Cleaned dataset shape: {df.shape}")
    return df


# ─────────────────────────────────────────────────────────────
# 3. FEATURE ENGINEERING
# ─────────────────────────────────────────────────────────────
def engineer_features(df: pd.DataFrame) -> pd.DataFrame:
    """
    Create new features that add predictive power.
    """
    df = df.copy()

    # Tenure bands (customer lifecycle stage)
    df['TenureBand'] = pd.cut(
        df['tenure'],
        bins=[-1, 12, 24, 48, 60, np.inf],
        labels=['0–12m', '12–24m', '24–48m', '48–60m', '60m+']
    ).astype(str)

    # Total number of subscribed services
    service_cols = [
        'PhoneService', 'MultipleLines', 'OnlineSecurity', 'OnlineBackup',
        'DeviceProtection', 'TechSupport', 'StreamingTV', 'StreamingMovies'
    ]
    df['NumServices'] = df[service_cols].apply(
        lambda row: (row == 'Yes').sum(), axis=1
    )

    # Average monthly spend per service (avoids division by zero)
    df['ChargePerService'] = np.where(
        df['NumServices'] > 0,
        df['MonthlyCharges'] / df['NumServices'],
        df['MonthlyCharges']
    )

    # Loyalty flag: customers with tenure > 24 months
    df['LongTenure'] = (df['tenure'] > 24).astype(int)

    # High-value customer flag
    df['HighValue'] = (df['MonthlyCharges'] > df['MonthlyCharges'].median()).astype(int)

    print(f"✅ Feature engineering complete. New shape: {df.shape}")
    return df


# ─────────────────────────────────────────────────────────────
# 4. ENCODE CATEGORICALS
# ─────────────────────────────────────────────────────────────
def encode_features(df: pd.DataFrame):
    """
    One-hot-encode nominal columns, label-encode ordinal columns.
    Returns (encoded_df, label_encoders_dict).
    """
    df = df.copy()

    # Columns to one-hot-encode
    ohe_cols = [
        'gender', 'Partner', 'Dependents', 'PhoneService', 'MultipleLines',
        'InternetService', 'OnlineSecurity', 'OnlineBackup', 'DeviceProtection',
        'TechSupport', 'StreamingTV', 'StreamingMovies', 'Contract',
        'PaperlessBilling', 'PaymentMethod', 'TenureBand'
    ]
    ohe_cols = [c for c in ohe_cols if c in df.columns]

    df = pd.get_dummies(df, columns=ohe_cols, drop_first=True)

    # Ensure no NaN remains (bool columns from get_dummies can be NaN for unseen values)
    df = df.fillna(0)

    # Convert bool columns to int
    bool_cols = df.select_dtypes(include='bool').columns
    df[bool_cols] = df[bool_cols].astype(int)

    print(f"✅ Encoding complete. Shape: {df.shape}")
    return df


# ─────────────────────────────────────────────────────────────
# 5. SCALE NUMERICAL FEATURES
# ─────────────────────────────────────────────────────────────
def scale_features(X_train, X_test, num_cols: list):
    """
    StandardScaler fit on train, applied to both train and test.
    Returns (X_train_scaled, X_test_scaled, scaler).
    """
    scaler = StandardScaler()
    X_train[num_cols] = scaler.fit_transform(X_train[num_cols])
    X_test[num_cols]  = scaler.transform(X_test[num_cols])
    return X_train, X_test, scaler


# ─────────────────────────────────────────────────────────────
# 6. FULL PIPELINE
# ─────────────────────────────────────────────────────────────
def preprocess_pipeline(filepath: str, save_dir: str = 'models'):
    """
    End-to-end preprocessing.
    Returns X_train, X_test, y_train, y_test, feature_names.
    """
    os.makedirs(save_dir, exist_ok=True)

    # Load & clean
    df = load_data(filepath)
    df = clean_data(df)
    df = engineer_features(df)
    df = encode_features(df)

    # Separate target
    X = df.drop(columns=['Churn'])
    y = df['Churn']

    feature_names = X.columns.tolist()

    # Numerical columns to scale
    num_cols = ['tenure', 'MonthlyCharges', 'TotalCharges',
                'NumServices', 'ChargePerService', 'LongTenure', 'HighValue']
    num_cols = [c for c in num_cols if c in X.columns]

    # Train / test split (stratified)
    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.20, random_state=42, stratify=y
    )

    X_train, X_test, scaler = scale_features(X_train.copy(), X_test.copy(), num_cols)

    # Persist scaler and feature names
    joblib.dump(scaler, os.path.join(save_dir, 'scaler.pkl'))
    joblib.dump(feature_names, os.path.join(save_dir, 'feature_names.pkl'))
    joblib.dump(num_cols, os.path.join(save_dir, 'num_cols.pkl'))

    print(f"\n📦 Train: {X_train.shape}  |  Test: {X_test.shape}")
    print(f"📦 Churn rate – Train: {y_train.mean():.1%}  Test: {y_test.mean():.1%}")
    return X_train, X_test, y_train, y_test, feature_names


# ─────────────────────────────────────────────────────────────
# HELPER: preprocess a single prediction row (for Streamlit)
# ─────────────────────────────────────────────────────────────
def preprocess_single(input_dict: dict, model_dir: str = 'models') -> pd.DataFrame:
    """
    Transform a single customer dict into a model-ready DataFrame.
    Loads scaler / feature names saved during training.
    """
    scaler       = joblib.load(os.path.join(model_dir, 'scaler.pkl'))
    feature_names= joblib.load(os.path.join(model_dir, 'feature_names.pkl'))
    num_cols     = joblib.load(os.path.join(model_dir, 'num_cols.pkl'))

    row = pd.DataFrame([input_dict])

    # Feature engineering
    row = engineer_features(row)
    row = encode_features(row)

    # Align columns to training feature set
    for col in feature_names:
        if col not in row.columns:
            row[col] = 0
    row = row[feature_names]

    # Scale numerics
    row[num_cols] = scaler.transform(row[num_cols])
    return row


if __name__ == '__main__':
    X_train, X_test, y_train, y_test, features = preprocess_pipeline(
        'data/telecom_churn.csv'
    )
    print(f"\nFeatures ({len(features)}):\n{features[:10]} …")
