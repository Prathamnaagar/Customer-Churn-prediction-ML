"""
app.py
======
Professional Streamlit application for Customer Churn Prediction.
Supports single prediction with probability gauge, feature insights,
business recommendations, and CSV batch download.
"""

import os
import io
import numpy as np
import pandas as pd
import joblib
import streamlit as st
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import matplotlib.patches as mpatches
from matplotlib.patches import Arc, FancyArrowPatch
import math

# ─────────────────────────────────────────────────────────────
# PAGE CONFIG
# ─────────────────────────────────────────────────────────────
st.set_page_config(
    page_title="Customer Churn Predictor",
    page_icon="🔮",
    layout="wide",
    initial_sidebar_state="expanded",
)

# ─────────────────────────────────────────────────────────────
# DARK THEME CSS
# ─────────────────────────────────────────────────────────────
st.markdown("""
<style>
/* ── global dark ── */
html, body, [class*="css"] {
    background-color: #1A1A2E !important;
    color: #E8E8E8 !important;
    font-family: 'Inter', 'DejaVu Sans', sans-serif;
}

/* ── sidebar ── */
section[data-testid="stSidebar"] {
    background: linear-gradient(180deg, #16213E 0%, #0F3460 100%) !important;
    border-right: 1px solid #2A2A4A;
}
section[data-testid="stSidebar"] * { color: #E8E8E8 !important; }

/* ── top header strip ── */
.header-strip {
    background: linear-gradient(135deg, #6C63FF 0%, #FF6584 100%);
    padding: 22px 30px;
    border-radius: 14px;
    margin-bottom: 24px;
    text-align: center;
    box-shadow: 0 8px 32px rgba(108,99,255,0.35);
}
.header-strip h1 { color: white !important; margin: 0; font-size: 2.1rem; }
.header-strip p  { color: rgba(255,255,255,0.85) !important; margin: 6px 0 0; }

/* ── metric cards ── */
.metric-card {
    background: #16213E;
    border: 1px solid #2A2A4A;
    border-radius: 12px;
    padding: 18px 22px;
    text-align: center;
    box-shadow: 0 4px 20px rgba(0,0,0,0.3);
    transition: transform 0.2s;
}
.metric-card:hover { transform: translateY(-3px); }
.metric-card .label { font-size: 0.82rem; color: #9CA3AF; margin-bottom: 4px; }
.metric-card .value { font-size: 1.8rem; font-weight: 700; color: #6C63FF; }
.metric-card .sub   { font-size: 0.75rem; color: #6B7280; margin-top: 2px; }

/* ── section dividers ── */
.section-title {
    font-size: 1.1rem;
    font-weight: 700;
    color: #6C63FF;
    border-bottom: 2px solid #6C63FF40;
    padding-bottom: 6px;
    margin: 18px 0 14px;
}

/* ── prediction result box ── */
.result-churn {
    background: linear-gradient(135deg, #FF6584 0%, #FF4069 100%);
    border-radius: 14px;
    padding: 24px;
    text-align: center;
    box-shadow: 0 8px 32px rgba(255,101,132,0.4);
}
.result-no-churn {
    background: linear-gradient(135deg, #43C6AC 0%, #35A892 100%);
    border-radius: 14px;
    padding: 24px;
    text-align: center;
    box-shadow: 0 8px 32px rgba(67,198,172,0.4);
}
.result-churn h2, .result-no-churn h2 { color: white !important; margin: 0; font-size: 1.7rem; }
.result-churn p,  .result-no-churn p  { color: rgba(255,255,255,0.9) !important; margin: 8px 0 0; }

/* ── recommendation cards ── */
.rec-card {
    background: #16213E;
    border-left: 4px solid #6C63FF;
    border-radius: 0 10px 10px 0;
    padding: 12px 16px;
    margin: 8px 0;
    font-size: 0.9rem;
}
.rec-urgent { border-left-color: #FF6584 !important; }
.rec-card strong { color: #6C63FF; }

/* ── streamlit widget overrides ── */
.stSelectbox label, .stSlider label, .stNumberInput label,
.stRadio label, .stCheckbox label {
    color: #C8C8D0 !important;
    font-size: 0.85rem !important;
}
div[data-testid="stSlider"] .st-b7 { color: #6C63FF; }
.stButton>button {
    background: linear-gradient(135deg, #6C63FF, #FF6584);
    color: white;
    border: none;
    border-radius: 10px;
    padding: 10px 28px;
    font-weight: 600;
    font-size: 1rem;
    letter-spacing: 0.5px;
    width: 100%;
    transition: opacity 0.2s;
}
.stButton>button:hover { opacity: 0.88; }
.stDownloadButton>button {
    background: #16213E;
    color: #43C6AC;
    border: 1px solid #43C6AC;
    border-radius: 8px;
    padding: 6px 18px;
    font-size: 0.85rem;
}

/* inputs dark */
input, select, textarea,
div[data-baseweb="select"] > div,
div[data-baseweb="input"]  > div {
    background-color: #0F172A !important;
    color: #E8E8E8 !important;
    border-color: #2A2A4A !important;
}
</style>
""", unsafe_allow_html=True)

# ─────────────────────────────────────────────────────────────
# LOAD MODEL ARTIFACTS
# ─────────────────────────────────────────────────────────────
MODEL_DIR = 'models'

@st.cache_resource
def load_artifacts():
    model        = joblib.load(os.path.join(MODEL_DIR, 'best_model.pkl'))
    scaler       = joblib.load(os.path.join(MODEL_DIR, 'scaler.pkl'))
    feature_names= joblib.load(os.path.join(MODEL_DIR, 'feature_names.pkl'))
    num_cols     = joblib.load(os.path.join(MODEL_DIR, 'num_cols.pkl'))
    model_name   = joblib.load(os.path.join(MODEL_DIR, 'best_model_name.pkl'))
    return model, scaler, feature_names, num_cols, model_name

model, scaler, feature_names, num_cols, model_name = load_artifacts()

# ─────────────────────────────────────────────────────────────
# PREPROCESSING HELPERS  (mirror of preprocess.py – avoids import issues)
# ─────────────────────────────────────────────────────────────
def engineer_features_app(df):
    df = df.copy()
    df['TenureBand'] = pd.cut(
        df['tenure'], bins=[-1, 12, 24, 48, 60, np.inf],
        labels=['0–12m', '12–24m', '24–48m', '48–60m', '60m+']
    ).astype(str)
    service_cols = [
        'PhoneService', 'MultipleLines', 'OnlineSecurity', 'OnlineBackup',
        'DeviceProtection', 'TechSupport', 'StreamingTV', 'StreamingMovies'
    ]
    df['NumServices'] = df[service_cols].apply(lambda r: (r == 'Yes').sum(), axis=1)
    df['ChargePerService'] = np.where(
        df['NumServices'] > 0, df['MonthlyCharges'] / df['NumServices'], df['MonthlyCharges']
    )
    df['LongTenure'] = (df['tenure'] > 24).astype(int)
    df['HighValue']  = (df['MonthlyCharges'] > 64.76).astype(int)  # training median
    return df


def encode_features_app(df):
    ohe_cols = [
        'gender', 'Partner', 'Dependents', 'PhoneService', 'MultipleLines',
        'InternetService', 'OnlineSecurity', 'OnlineBackup', 'DeviceProtection',
        'TechSupport', 'StreamingTV', 'StreamingMovies', 'Contract',
        'PaperlessBilling', 'PaymentMethod', 'TenureBand'
    ]
    ohe_cols = [c for c in ohe_cols if c in df.columns]
    df = pd.get_dummies(df, columns=ohe_cols, drop_first=True)
    df = df.fillna(0)
    bool_cols = df.select_dtypes(include='bool').columns
    df[bool_cols] = df[bool_cols].astype(int)
    return df


def preprocess_input(input_dict):
    row = pd.DataFrame([input_dict])
    row = engineer_features_app(row)
    row = encode_features_app(row)
    for col in feature_names:
        if col not in row.columns:
            row[col] = 0
    row = row[feature_names]
    row[num_cols] = scaler.transform(row[num_cols])
    return row


# ─────────────────────────────────────────────────────────────
# GAUGE CHART
# ─────────────────────────────────────────────────────────────
def gauge_chart(probability: float, size: int = 280):
    """Draw a semi-circular gauge for churn probability."""
    fig, ax = plt.subplots(figsize=(size/96, size/96*0.6),
                            facecolor='none')
    ax.set_facecolor('none')
    ax.set_aspect('equal')
    ax.axis('off')

    # Arc zones
    zone_colors = ['#43C6AC', '#F7971E', '#FF6584']
    zone_limits = [0, 0.33, 0.66, 1.0]
    for i in range(3):
        theta1 = 180 - zone_limits[i]*180
        theta2 = 180 - zone_limits[i+1]*180
        arc = Arc((0.5, 0.1), 0.8, 0.8, angle=0,
                  theta1=theta2, theta2=theta1,
                  color=zone_colors[i], lw=18, solid_capstyle='butt')
        ax.add_patch(arc)

    # Needle
    angle = math.radians(180 - probability * 180)
    x = 0.5 + 0.36 * math.cos(angle)
    y = 0.1 + 0.36 * math.sin(angle)
    ax.annotate('', xy=(x, y), xytext=(0.5, 0.1),
                arrowprops=dict(arrowstyle='->', color='white',
                                lw=2.5, mutation_scale=18))
    ax.plot(0.5, 0.1, 'o', color='white', markersize=8, zorder=5)

    # Probability text
    ax.text(0.5, 0.38, f'{probability:.0%}',
            ha='center', va='center', fontsize=22,
            fontweight='bold', color='white', transform=ax.transAxes)

    ax.set_xlim(0, 1)
    ax.set_ylim(-0.05, 0.75)
    return fig


# ─────────────────────────────────────────────────────────────
# BUSINESS RECOMMENDATIONS
# ─────────────────────────────────────────────────────────────
def get_recommendations(inp: dict, prob: float) -> list[dict]:
    recs = []
    urgent = prob > 0.6

    if inp['Contract'] == 'Month-to-month':
        recs.append({
            'icon': '📋', 'urgent': urgent,
            'title': 'Offer Long-term Contract Incentive',
            'detail': 'Month-to-month customers churn 3× more. Offer 1–2 month free '
                      'upgrade if they commit to a 12-month plan.'
        })

    if inp['tenure'] < 12:
        recs.append({
            'icon': '🎯', 'urgent': urgent,
            'title': 'Activate Early Retention Program',
            'detail': 'New customers churn most in the first year. Assign a '
                      'dedicated onboarding specialist and schedule a 90-day check-in.'
        })

    if inp['MonthlyCharges'] > 70:
        recs.append({
            'icon': '💰', 'urgent': False,
            'title': 'Provide Loyalty Pricing Discount',
            'detail': f'Customer pays ${inp["MonthlyCharges"]:.0f}/month. A 10–15% loyalty '
                      'discount could cost less than the CAC for a replacement.'
        })

    if inp['InternetService'] == 'Fiber optic':
        recs.append({
            'icon': '📡', 'urgent': False,
            'title': 'Proactive Fiber Quality Outreach',
            'detail': 'Fiber optic subscribers have the highest churn rate. '
                      'Send a proactive satisfaction survey and offer a free speed upgrade.'
        })

    if inp['PaymentMethod'] == 'Electronic check':
        recs.append({
            'icon': '💳', 'urgent': False,
            'title': 'Encourage Auto-Pay Enrollment',
            'detail': 'Electronic check users churn more. Offer a $5/month discount '
                      'for switching to automatic credit card or bank transfer.'
        })

    if inp['TechSupport'] == 'No' and inp['InternetService'] != 'No':
        recs.append({
            'icon': '🛠️', 'urgent': False,
            'title': 'Upsell Tech Support Bundle',
            'detail': 'Customers without tech support are more likely to churn due to '
                      'unresolved issues. Offer a free 3-month trial of tech support.'
        })

    if not recs:
        recs.append({
            'icon': '✅', 'urgent': False,
            'title': 'Continue Engagement Program',
            'detail': 'This customer shows low churn risk. Maintain quarterly '
                      'check-ins and consider upsell opportunities for additional services.'
        })

    return recs


# ─────────────────────────────────────────────────────────────
# SIDEBAR – CUSTOMER INPUT FORM
# ─────────────────────────────────────────────────────────────
def sidebar_inputs() -> dict:
    st.sidebar.markdown("""
    <div style='text-align:center; padding:12px 0 18px;'>
      <span style='font-size:2rem;'>🔮</span>
      <div style='font-size:1.1rem; font-weight:700; color:#6C63FF; margin-top:4px;'>
        Churn Predictor
      </div>
      <div style='font-size:0.75rem; color:#9CA3AF;'>Input customer details below</div>
    </div>
    """, unsafe_allow_html=True)

    st.sidebar.markdown('<div class="section-title">👤 Demographics</div>',
                        unsafe_allow_html=True)
    gender          = st.sidebar.selectbox('Gender', ['Male', 'Female'])
    senior_citizen  = st.sidebar.radio('Senior Citizen', ['No', 'Yes'], horizontal=True)
    partner         = st.sidebar.radio('Partner', ['No', 'Yes'], horizontal=True)
    dependents      = st.sidebar.radio('Dependents', ['No', 'Yes'], horizontal=True)

    st.sidebar.markdown('<div class="section-title">📞 Services</div>',
                        unsafe_allow_html=True)
    phone_service = st.sidebar.selectbox('Phone Service', ['Yes', 'No'])
    multiple_lines = st.sidebar.selectbox(
        'Multiple Lines',
        ['No', 'Yes', 'No phone service']
        if phone_service == 'Yes' else ['No phone service']
    )
    internet_service = st.sidebar.selectbox(
        'Internet Service', ['Fiber optic', 'DSL', 'No']
    )

    if internet_service != 'No':
        online_security   = st.sidebar.selectbox('Online Security', ['No', 'Yes'])
        online_backup     = st.sidebar.selectbox('Online Backup', ['No', 'Yes'])
        device_protection = st.sidebar.selectbox('Device Protection', ['No', 'Yes'])
        tech_support      = st.sidebar.selectbox('Tech Support', ['No', 'Yes'])
        streaming_tv      = st.sidebar.selectbox('Streaming TV', ['No', 'Yes'])
        streaming_movies  = st.sidebar.selectbox('Streaming Movies', ['No', 'Yes'])
    else:
        online_security = online_backup = device_protection = \
        tech_support = streaming_tv = streaming_movies = 'No internet service'

    st.sidebar.markdown('<div class="section-title">💼 Account</div>',
                        unsafe_allow_html=True)
    tenure   = st.sidebar.slider('Tenure (months)', 0, 72, 12)
    contract = st.sidebar.selectbox(
        'Contract Type', ['Month-to-month', 'One year', 'Two year']
    )
    paperless_billing = st.sidebar.radio(
        'Paperless Billing', ['Yes', 'No'], horizontal=True
    )
    payment_method = st.sidebar.selectbox(
        'Payment Method',
        ['Electronic check', 'Mailed check',
         'Bank transfer (automatic)', 'Credit card (automatic)']
    )

    st.sidebar.markdown('<div class="section-title">💵 Charges</div>',
                        unsafe_allow_html=True)
    monthly_charges = st.sidebar.number_input(
        'Monthly Charges ($)', min_value=18.0, max_value=120.0,
        value=65.0, step=0.5
    )
    total_charges = st.sidebar.number_input(
        'Total Charges ($)', min_value=0.0, max_value=9000.0,
        value=float(round(monthly_charges * tenure, 2)), step=0.01
    )

    return {
        'gender': gender,
        'SeniorCitizen': 1 if senior_citizen == 'Yes' else 0,
        'Partner': partner,
        'Dependents': dependents,
        'tenure': tenure,
        'PhoneService': phone_service,
        'MultipleLines': multiple_lines,
        'InternetService': internet_service,
        'OnlineSecurity': online_security,
        'OnlineBackup': online_backup,
        'DeviceProtection': device_protection,
        'TechSupport': tech_support,
        'StreamingTV': streaming_tv,
        'StreamingMovies': streaming_movies,
        'Contract': contract,
        'PaperlessBilling': paperless_billing,
        'PaymentMethod': payment_method,
        'MonthlyCharges': monthly_charges,
        'TotalCharges': total_charges,
    }


# ─────────────────────────────────────────────────────────────
# MAIN APP
# ─────────────────────────────────────────────────────────────
def main():
    # ── Header ──────────────────────────────────────────────
    st.markdown("""
    <div class='header-strip'>
      <h1>🔮 Customer Churn Prediction</h1>
      <p>AI-powered churn risk assessment · Telecom Analytics Dashboard</p>
    </div>
    """, unsafe_allow_html=True)

    # ── Inputs from sidebar ──────────────────────────────────
    inp = sidebar_inputs()
    predict_btn = st.sidebar.button('🚀 Predict Churn', use_container_width=True)

    # ── KPI overview row ────────────────────────────────────
    col1, col2, col3, col4 = st.columns(4)
    with col1:
        st.markdown(f"""
        <div class='metric-card'>
            <div class='label'>Tenure</div>
            <div class='value'>{inp['tenure']}</div>
            <div class='sub'>months</div>
        </div>""", unsafe_allow_html=True)
    with col2:
        st.markdown(f"""
        <div class='metric-card'>
            <div class='label'>Monthly Charges</div>
            <div class='value'>${inp['MonthlyCharges']:.0f}</div>
            <div class='sub'>per month</div>
        </div>""", unsafe_allow_html=True)
    with col3:
        st.markdown(f"""
        <div class='metric-card'>
            <div class='label'>Contract</div>
            <div class='value' style='font-size:1.1rem;'>{inp['Contract']}</div>
            <div class='sub'>type</div>
        </div>""", unsafe_allow_html=True)
    with col4:
        st.markdown(f"""
        <div class='metric-card'>
            <div class='label'>Internet</div>
            <div class='value' style='font-size:1.1rem;'>{inp['InternetService']}</div>
            <div class='sub'>service</div>
        </div>""", unsafe_allow_html=True)

    st.markdown("<br>", unsafe_allow_html=True)

    # ── Tabs ────────────────────────────────────────────────
    tab_predict, tab_eda, tab_model, tab_batch = st.tabs(
        ['🎯 Prediction', '📊 EDA Dashboard', '📈 Model Performance', '📁 Batch Predict']
    )

    # ══════════════════════════════════════════════════════
    # TAB 1 – PREDICTION
    # ══════════════════════════════════════════════════════
    with tab_predict:
        if predict_btn:
            with st.spinner('Running prediction…'):
                X_input = preprocess_input(inp)
                prob    = float(model.predict_proba(X_input)[0, 1])
                pred    = int(prob >= 0.5)

            left, right = st.columns([1, 1])

            # ── Result box
            with left:
                if pred == 1:
                    st.markdown(f"""
                    <div class='result-churn'>
                      <h2>⚠️ HIGH CHURN RISK</h2>
                      <p>This customer is likely to churn.<br>
                         Immediate retention action recommended.</p>
                    </div>""", unsafe_allow_html=True)
                else:
                    st.markdown(f"""
                    <div class='result-no-churn'>
                      <h2>✅ LOW CHURN RISK</h2>
                      <p>This customer is likely to stay.<br>
                         Continue standard engagement.</p>
                    </div>""", unsafe_allow_html=True)

                st.markdown("<br>", unsafe_allow_html=True)

                # Progress bar confidence
                bar_color = '#FF6584' if pred else '#43C6AC'
                st.markdown(f"""
                <div style='margin:8px 0 4px; font-size:0.85rem; color:#9CA3AF;'>
                    Churn Probability
                </div>
                <div style='background:#0F172A; border-radius:8px; height:22px; overflow:hidden;'>
                  <div style='width:{prob*100:.1f}%; background:{bar_color};
                              height:100%; border-radius:8px; transition:width 0.5s;
                              display:flex; align-items:center; justify-content:center;
                              font-size:0.78rem; color:white; font-weight:600;'>
                    {prob:.1%}
                  </div>
                </div>
                """, unsafe_allow_html=True)

                # Risk label
                risk_label = (
                    ('🟢 Low Risk',      '#43C6AC') if prob < 0.33 else
                    ('🟡 Medium Risk',   '#F7971E') if prob < 0.66 else
                    ('🔴 High Risk',     '#FF6584')
                )
                st.markdown(f"""
                <div style='margin-top:14px; text-align:center;
                            font-size:1rem; font-weight:700; color:{risk_label[1]};'>
                    {risk_label[0]}  ·  Confidence: {max(prob, 1-prob):.1%}
                </div>
                """, unsafe_allow_html=True)

            # ── Gauge
            with right:
                st.markdown('<div style="text-align:center; color:#9CA3AF; font-size:0.85rem; '
                            'margin-bottom:4px;">Churn Probability Gauge</div>',
                            unsafe_allow_html=True)
                fig_gauge = gauge_chart(prob)
                st.pyplot(fig_gauge, use_container_width=True, transparent=True)

            st.markdown("---")

            # ── Recommendations
            st.markdown('<div class="section-title">💡 Business Recommendations</div>',
                        unsafe_allow_html=True)
            recs = get_recommendations(inp, prob)
            for rec in recs:
                urgency_cls = 'rec-urgent' if rec['urgent'] else ''
                st.markdown(f"""
                <div class='rec-card {urgency_cls}'>
                  <strong>{rec['icon']} {rec['title']}</strong><br>
                  <span style='color:#C8C8D0;'>{rec['detail']}</span>
                </div>
                """, unsafe_allow_html=True)

            # ── Download single result
            result_df = pd.DataFrame([{**inp, 'Churn_Probability': f'{prob:.4f}',
                                        'Prediction': 'Churn' if pred else 'No Churn'}])
            csv_bytes = result_df.to_csv(index=False).encode()
            st.markdown("<br>", unsafe_allow_html=True)
            st.download_button(
                '⬇️  Download Result as CSV', data=csv_bytes,
                file_name='churn_prediction.csv', mime='text/csv'
            )

        else:
            st.markdown("""
            <div style='text-align:center; padding:60px 20px; color:#6B7280;'>
              <div style='font-size:3rem; margin-bottom:14px;'>🔮</div>
              <div style='font-size:1.1rem;'>
                Fill in the customer details in the <b style='color:#6C63FF;'>sidebar</b>
                and click <b style='color:#FF6584;'>Predict Churn</b>
              </div>
            </div>
            """, unsafe_allow_html=True)

    # ══════════════════════════════════════════════════════
    # TAB 2 – EDA DASHBOARD
    # ══════════════════════════════════════════════════════
    with tab_eda:
        st.markdown('<div class="section-title">📊 Exploratory Data Analysis</div>',
                    unsafe_allow_html=True)

        eda_images = [
            ('eda_02_churn_distribution.png',  'Churn Distribution',
             '~23% of customers churn – an imbalanced dataset requiring careful model evaluation.'),
            ('eda_03_churn_by_gender.png',     'Churn by Gender',
             'Gender shows minimal impact on churn. Focus on contract & tenure instead.'),
            ('eda_04_churn_by_contract.png',   'Churn by Contract Type',
             'Month-to-month customers churn 3–4× more than long-term contract holders.'),
            ('eda_05_churn_by_payment.png',    'Churn by Payment Method',
             'Electronic check users churn most. Auto-pay enrollment reduces churn risk.'),
            ('eda_06_monthly_charges_vs_churn.png', 'Monthly Charges vs Churn',
             'Churned customers pay higher monthly fees. High-spend loyalty discounts help.'),
            ('eda_07_tenure_vs_churn.png',     'Tenure vs Churn',
             'First-year customers churn most. Invest in early-stage onboarding programs.'),
            ('eda_08_correlation_heatmap.png', 'Correlation Heatmap',
             'Tenure is negatively correlated with churn. Monthly & Total charges are collinear.'),
            ('eda_09_internet_senior.png',     'Internet Service & Senior Citizens',
             'Fiber optic and senior customers have the highest churn rates.'),
        ]

        for i in range(0, len(eda_images), 2):
            cols = st.columns(2)
            for j, col in enumerate(cols):
                if i + j < len(eda_images):
                    fname, title, insight = eda_images[i + j]
                    path = os.path.join('assets', fname)
                    with col:
                        st.markdown(f"**{title}**")
                        if os.path.exists(path):
                            st.image(path, use_column_width=True)
                        else:
                            st.info('Run `python notebook/eda.py` to generate this chart.')
                        st.caption(f"💡 {insight}")
            st.markdown("<br>", unsafe_allow_html=True)

    # ══════════════════════════════════════════════════════
    # TAB 3 – MODEL PERFORMANCE
    # ══════════════════════════════════════════════════════
    with tab_model:
        st.markdown('<div class="section-title">📈 Model Performance Dashboard</div>',
                    unsafe_allow_html=True)

        results_path = os.path.join('assets', 'model_results.csv')
        if os.path.exists(results_path):
            results_df = pd.read_csv(results_path, index_col=0)

            # Best model badge
            best = results_df['ROC-AUC'].idxmax()
            st.markdown(f"""
            <div style='background:linear-gradient(135deg,#6C63FF,#FF6584);
                        border-radius:12px; padding:16px 22px; margin-bottom:20px;
                        display:inline-block;'>
              <span style='color:white; font-weight:700; font-size:1.05rem;'>
                🏆 Best Model: {best}  ·  ROC-AUC: {results_df.loc[best,'ROC-AUC']:.4f}
              </span>
            </div>
            """, unsafe_allow_html=True)

            # Metrics table
            st.dataframe(
                results_df.style
                    .highlight_max(axis=0, color='#6C63FF33')
                    .format('{:.4f}'),
                use_container_width=True
            )
        else:
            st.info('Run `python train.py` to generate model results.')

        model_images = [
            ('model_comparison.png',    'Model Comparison Bar Chart'),
            ('roc_curves.png',          'ROC Curves'),
            ('confusion_matrices.png',  'Confusion Matrices'),
            ('feature_importance_random_forest.png',    'Random Forest – Feature Importance'),
            ('feature_importance_gradient_boosting.png','Gradient Boosting – Feature Importance'),
        ]

        for fname, title in model_images:
            path = os.path.join('assets', fname)
            if os.path.exists(path):
                st.markdown(f"**{title}**")
                st.image(path, use_column_width=True)
                st.markdown("<br>", unsafe_allow_html=True)

    # ══════════════════════════════════════════════════════
    # TAB 4 – BATCH PREDICTION
    # ══════════════════════════════════════════════════════
    with tab_batch:
        st.markdown('<div class="section-title">📁 Batch Prediction via CSV Upload</div>',
                    unsafe_allow_html=True)

        st.info(
            "Upload a CSV with customer records. Required columns: gender, SeniorCitizen, "
            "Partner, Dependents, tenure, PhoneService, MultipleLines, InternetService, "
            "OnlineSecurity, OnlineBackup, DeviceProtection, TechSupport, StreamingTV, "
            "StreamingMovies, Contract, PaperlessBilling, PaymentMethod, MonthlyCharges, TotalCharges."
        )

        uploaded = st.file_uploader('Upload CSV', type=['csv'])
        if uploaded:
            raw_df = pd.read_csv(uploaded)
            st.markdown(f"**Rows loaded:** {len(raw_df):,}")
            st.dataframe(raw_df.head(), use_container_width=True)

            if st.button('🚀 Run Batch Prediction'):
                with st.spinner('Processing…'):
                    results_list = []
                    for _, row in raw_df.iterrows():
                        row_dict = row.to_dict()
                        try:
                            X  = preprocess_input(row_dict)
                            pr = float(model.predict_proba(X)[0, 1])
                            pred_label = 'Churn' if pr >= 0.5 else 'No Churn'
                            risk = ('Low' if pr < 0.33 else
                                    'Medium' if pr < 0.66 else 'High')
                        except Exception:
                            pr, pred_label, risk = None, 'Error', 'Unknown'
                        results_list.append({
                            **row_dict,
                            'Churn_Probability': round(pr, 4) if pr is not None else None,
                            'Prediction': pred_label,
                            'Risk_Level': risk,
                        })

                    out_df = pd.DataFrame(results_list)

                churn_count = (out_df['Prediction'] == 'Churn').sum()
                total       = len(out_df)

                c1, c2, c3 = st.columns(3)
                with c1:
                    st.markdown(f"""
                    <div class='metric-card'>
                        <div class='label'>Total Customers</div>
                        <div class='value'>{total:,}</div>
                    </div>""", unsafe_allow_html=True)
                with c2:
                    st.markdown(f"""
                    <div class='metric-card'>
                        <div class='label'>Predicted Churners</div>
                        <div class='value' style='color:#FF6584;'>{churn_count:,}</div>
                    </div>""", unsafe_allow_html=True)
                with c3:
                    st.markdown(f"""
                    <div class='metric-card'>
                        <div class='label'>Churn Rate</div>
                        <div class='value' style='color:#F7971E;'>
                            {churn_count/total:.1%}
                        </div>
                    </div>""", unsafe_allow_html=True)

                st.markdown("<br>", unsafe_allow_html=True)
                st.dataframe(out_df[['Prediction', 'Churn_Probability', 'Risk_Level']
                                    + [c for c in raw_df.columns[:5]]].head(20),
                             use_container_width=True)

                csv_out = out_df.to_csv(index=False).encode()
                st.download_button(
                    '⬇️  Download Full Results CSV', data=csv_out,
                    file_name='batch_churn_predictions.csv', mime='text/csv'
                )

    # ── Footer ────────────────────────────────────────────
    st.markdown("---")
    st.markdown(f"""
    <div style='text-align:center; color:#6B7280; font-size:0.8rem; padding:10px 0;'>
      🔮 Customer Churn Prediction App · Built with Streamlit · Model: <b>{model_name}</b>
    </div>
    """, unsafe_allow_html=True)


if __name__ == '__main__':
    main()
